from ninja import Router
from .models import *
from .forms import *

router = Router()

#add functionality
